// JavaScript Document
//window.addEvent('load', function(){
/*jQuery(document).ready(function($){ //alert('dungnv');
	if($('#menu')!=null){
		$('#menu').append('<li class="yt-clearcache dropdown"></li>');
		$('.yt-clearcache').append('<a style="background: url(../plugins/system/yt/includes/images/clean-cache.png) no-repeat left center; padding-left:15px;" href="javascript:void(0)">Clean cache: CSS, JS</a>');
		$('.yt-clearcache a').click(function(){
			var linkurl = '../index.php?action=clearCache&type=plugin';
			$.post(linkurl, function() {
			})
			.error(function() { alert("Error..."); })
			.complete(function() { alert("Clear cache successful !") }); 
		});
	}
});*/
